const noBtn = document.getElementById('no-btn');
const yesBtn = document.getElementById('yes-btn');
const mainCard = document.getElementById('main-card');
const resultCard = document.getElementById('result-card');

let yesScale = 1; // Tracks the size of the Yes button

const moveButton = () => {
    // 1. Move the "No" button to a random spot
    const x = Math.random() * (window.innerWidth - noBtn.offsetWidth);
    const y = Math.random() * (window.innerHeight - noBtn.offsetHeight);
    
    noBtn.style.position = 'fixed';
    noBtn.style.left = `${x}px`;
    noBtn.style.top = `${y}px`;

    // 2. Make the "Yes" button bigger
    yesScale += 0.2; // Increase size by 20%
    yesBtn.style.transform = `scale(${yesScale})`;
    
    // Optional: Add a little smooth transition to the Yes button
    yesBtn.style.transition = "transform 0.2s ease-in-out";
};

// Desktop: Move on hover
noBtn.addEventListener('mouseover', moveButton);

// Mobile: Move on touch
noBtn.addEventListener('touchstart', (e) => {
    e.preventDefault(); 
    moveButton();
});

// Success action
yesBtn.addEventListener('click', () => {
    mainCard.classList.add('hidden');
    resultCard.classList.remove('hidden');
    // Ensure the No button disappears on the result screen
    noBtn.style.display = 'none';
});